/**
 * Layout component that queries for data
 * with Gatsby's useStaticQuery component
 *
 * See: https://www.gatsbyjs.com/docs/use-static-query/
 */

import React, { useEffect, useState } from "react"
import Navbar from "./Navbar"
import "../styles/mains.scss"

const Layout = ({ children }) => {
  const [darkTheme, setDarkTheme] = useState(false)

  useEffect(() => {
    setDarkTheme(window.matchMedia('(prefers-color-scheme: dark)').matches)
  }, [darkTheme])

  typeof window !== "undefined" &&
    document.addEventListener("mousemove", parallaxEffect)
  function parallaxEffect(e) {
    this.querySelectorAll(".layer").forEach(layer => {
      const speed = layer.getAttribute("data-speed")

      const x = (window.innerWidth - e.pageX * speed) / 100
      const y = (window.innerHeight - e.pageY * speed) / 100

      layer.style.transform = `translateX(${x}px) translateY(${y}px)`
    })
  }

  return (
    <div className={darkTheme ? "dark-theme" : "light-theme"}>
      <Navbar/>
      <i
    data-speed="-5"
    className="fa fa-github layer parallaxImage Icon-1"
    />
      <i data-speed="2" className="fa fa-medium layer parallaxImage Icon-2"/>
      <i
    data-speed="-2"
    className="fa fa-stack-overflow layer parallaxImage Icon-3"
    />
      <i data-speed="7" className="fa fa-linux layer parallaxImage Icon-4"/>
      <i data-speed="5" className="fa fa-drupal layer parallaxImage Icon-5"/>
      <main>{children}</main>
    </div>
  )
}
export default Layout
